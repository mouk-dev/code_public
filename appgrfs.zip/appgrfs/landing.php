<?php
     include('header.php');
     include_once('nav.php');
?>

<?php
     include_once('footer.php');
?>