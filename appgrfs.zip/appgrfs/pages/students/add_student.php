<?php
     include('../header.php');
     include('nav.php');
?>
<div class="col-12 grid-margin stretch-card">
     <div class="card">
          <div class="card-body">
               <h4 class="card-title">Ajouter les étudiants</h4>
               <p class="card-description">Tous les champs du formulaires sont obligatoires</p>
               <form class="forms-sample">
                    <div class="form-group">
                         <label for="exampleInputName1">Nom de l'étudiant</label>
                         <input type="text" class="form-control" id="exampleInputName1" placeholder="Entrez le nom complet de l'étudiant" />
                    </div>

                    <div class="form-group">
                         <label for="exampleInputName1">Date de naissance de l'étudiant</label>
                         <input type="date" class="form-control" id="exampleInputName1" placeholder="Entrez date de naissance de l'étudiant" />
                    </div>

                    <div class="form-group">
                         <label for="exampleInputEmail3">Email de l'étudiant</label>
                         <input type="email" class="form-control" id="exampleInputEmail3" placeholder="Entrez l'email de l'étudiant" />
                    </div>

                    <div class="form-group">
                         <label for="exampleInputEmail3">Téléphone de l'étudiant</label>
                         <input type="tel" class="form-control" id="exampleInputEmail3" placeholder="Entrez téléphone de l'étudiant" />
                    </div>

                    <div class="form-group">
                         <label for="exampleSelectGender">Filière</label>
                         <select class="form-control" id="exampleSelectGender">
                              <option>Choisissez la filière</option>
                         </select>
                    </div>
                    
                    <div class="form-group">
                         <label for="exampleSelectGender">Option</label>
                         <select class="form-control" id="exampleSelectGender">
                              <option>Choisissez l'option</option>
                         </select>
                    </div>

                    <div class="form-group">
                         <label for="exampleSelectGender">Niveau</label>
                         <select class="form-control" id="exampleSelectGender">
                              <option>Choisissez le niveau</option>
                         </select>
                    </div>

                    <button type="submit" class="btn btn-primary mr-2">INSCRIRE UN ETUDIANT </button>
                    <button class="btn btn-danger">TOUT EFFACER</button>
               </form>
          </div>
     </div>
</div>
<?php
     include_once('../footer.php');
?>