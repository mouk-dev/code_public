<?php
     include('../header.php');
     include('nav.php');
?>
<div class="col-lg-12 grid-margin stretch-card">
     <div class="card card-calender">
          <div class="card-body bg-white">
               <div class="bg-white">
                    <h4>liste des étudiants</h4>
                    <ul class="d-flex pl-0 overflow-auto bg-white"> 
                         <li class="weakly-weather-item text-white text-center">
                              <div class="table-responsive">
                                   <table class="table table-striped">
                                        <thead>
                                             <tr>
                                                  <th>N°</th>
                                                  <th>Nom</th>
                                                  <th>date. N</th>
                                                  <th>Email</th>
                                                  <th>Contact</th>
                                                  <th>Filière</th>
                                                  <th>Option</th>
                                                  <th>Niveau</th>
                                                  <th colspan="2">Actions</th>
                                             </tr>
                                        </thead>
                                        <tbody>
                                             <tr>
                                                  <td>1</td>
                                                  <td>Mouksite BOURAIMA</td>
                                                  <td>20-05-2001</td>
                                                  <td>admin@gmail.com</td>
                                                  <td>66399757</td>
                                                  <td>GE</td>
                                                  <td>SIL</td>
                                                  <td>LICENCE1</td>
                                                  <td>
                                                       <a class="btn btn-primary btn-icon-text" href="update_user.php">
                                                            <i class="mdi mdi-pencil-box btn-icon-append"></i>
                                                       </a>
                                                  </td>
                                                  <td>
                                                       <a class="btn btn-danger btn-icon-text" href="update_user.php">
                                                            <i class="mdi mdi-delete btn-icon-append"></i>
                                                       </a>
                                                  </td>
                                             </tr>
                                        </tbody>
                                   </table>
                              </div>
                         </li>
                    </ul>
               </div>
          </div>
     </div>
</div>
<?php
     include_once('../footer.php');
?>