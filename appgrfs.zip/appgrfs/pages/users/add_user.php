<?php
     include('../header.php');
     include('nav.php');
?>
     <div class="col-12 grid-margin stretch-card">
          <div class="card">
               <div class="card-body">
                    <h4 class="card-title">Ajout des utilisateurs</h4>
                    <p class="card-description">Tous les champs du formulaires sont obligatoires</p>
                    <form class="forms-sample">
                         <div class="form-group">
                              <label for="exampleInputName1">Nom de l'utilisateur</label>
                              <input type="text" class="form-control" id="exampleInputName1" placeholder="Entrez le nom complet de l'utilisateur" />
                         </div>

                         <div class="form-group">
                              <label for="exampleInputEmail3">Email de l'utilisateur</label>
                              <input type="email" class="form-control" id="exampleInputEmail3" placeholder="Entrez l'email de l'utilisateur" />
                         </div>

                         <div class="form-group">
                              <label for="exampleInputPassword4">Choisir un mot de passe</label>
                              <input type="password" class="form-control" id="exampleInputPassword4" placeholder="Entrez un mot de passe" />
                         </div>

                         <div class="form-group">
                              <label for="exampleInputPassword4">Confirmez le mot de passe</label>
                              <input type="password" class="form-control" id="exampleInputPassword4" placeholder="Confirmez le mot de passe" />
                         </div>

                         <div class="form-group">
                              <label for="exampleSelectGender">Statut de l'utilisateur</label>
                              <select class="form-control" id="exampleSelectGender">
                                   <option>Administrateur</option>
                                   <option>Etudiant</option>
                              </select>
                         </div>

                         <div class="form-group">
                              <label>Importer une photo de profil</label>
                              <input type="file" name="img[]" class="file-upload-default" />
                              <div class="input-group col-xs-12">
                                   <input type="text" class="form-control file-upload-info" disabled placeholder="Importez une photo" />
                                   <span class="input-group-append">
                                        <button class="file-upload-browse btn btn-primary" type="button"> Importer </button>
                                   </span>
                              </div>
                         </div>

                         <button type="submit" class="btn btn-primary mr-2"> AJOUTER UN UTILISATEUR </button>
                         <button class="btn btn-danger">TOUT EFFACER</button>
                    </form>
               </div>
          </div>
     </div>
<?php
     include_once('../footer.php');
?>