<?php
     include('../header.php');
     include('nav.php');
?>
<div class="col-lg-12 grid-margin stretch-card">
     <div class="card card-calender">
          <div class="card-body bg-white">
               <div class="bg-white">
                    <h4>liste des étudiants</h4>
                    <ul class="d-flex pl-0 overflow-auto bg-white"> 
                         <li class="weakly-weather-item text-white text-center">
                              <div class="table-responsive">
                                   <table class="table table-striped">
                                        <thead>
                                             <tr>
                                                  <th>N°</th>
                                                  <th>Profil</th>
                                                  <th>Nom complet</th>
                                                  <th>Email</th>
                                                  <th>Statut</th>

                                                  <th>Statut</th>
                                                  <th>numéro</th>
                                                  <th>Statut</th>
                                                  <th colspan="2">Actions</th>
                                             </tr>
                                        </thead>
                                        <tbody>
                                             <tr>
                                                  <td class="py-1">1</td>
                                                  <td class="py-1">
                                                       <img src="../../assets/images/faces-clipart/pic-1.png" alt="image" />
                                                  </td>
                                                  <td>Mouksite BOURAIMA</td>
                                                  <td>admin@gmail.com</td>
                                                  <td>Administrateur</td>
                                                  <td>
                                                       <a class="btn btn-primary btn-icon-text" href="update_user.php">
                                                            Modifier <i class="mdi mdi-pencil-box btn-icon-append"></i>
                                                       </a>
                                                  </td>
                                                  <td>
                                                       <a class="btn btn-danger btn-icon-text" href="update_user.php">
                                                            Supprimer <i class="mdi mdi-delete btn-icon-append"></i>
                                                       </a>
                                                  </td>
                                             </tr>
                                        </tbody>
                                   </table>
                              </div>
                         </li>
                    </ul>
               </div>
          </div>
     </div>
</div>
<?php
     include_once('../footer.php');
?>