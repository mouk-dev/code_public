<?php
     include('../header.php');
     include('nav.php');
?>

<?php
     include_once('../footer.php');
?>