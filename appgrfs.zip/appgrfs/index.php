<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>CONNEXION APPGRFS</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- LINEARICONS -->
		<link rel="stylesheet" href="assets/form_login_assets/fonts/linearicons/style.css" />
		
		<!-- STYLE CSS -->
		<link rel="stylesheet" href="assets/form_login_assets/css/style.css">
		<link rel="shortcut icon" href="assets/images/logo_gasa.jpg" />
	</head>

	<body>

		<div class="wrapper">
			<div class="inner">
				<img src="assets/form_login_assets/images/image-1.png" alt="" class="image-1">
				<form action="" method="POST">
					<h3>Connexion</h3>
					<div class="form-holder">
						<span class="lnr lnr-envelope"></span>
						<input type="email" name="email" class="form-control" placeholder="Email d'utilisateur" required />
					</div>
					<div class="form-holder">
						<span class="lnr lnr-lock"></span>
						<input type="password" name="password" class="form-control" placeholder="Mot de passe" required />
					</div>
					<button type="submit" name="connecter">
						<span>Se connecter</span>
					</button><br />
					<div>
						<center>
							<span>UATM-GASA FORMATION</span>
						</center>
					</div>
				</form>
				<img src="assets/form_login_assets/images/image-2.png" alt="" class="image-2">
			</div>
			
		</div>
		
		<script src="js/jquery-3.3.1.min.js"></script>
		<script src="js/main.js"></script>
	</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>