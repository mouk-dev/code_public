<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>UATM-GASA APPGRFS</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="./assets/img/favicon.png" rel="icon">
  <link href="./assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="./assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="./assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="./assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="./assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="./assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="./assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="./assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="./assets/css/style.css" rel="stylesheet">
  <link rel="shortcut icon" href="./assets/images/logo_gasa.jpg" />
</head>
<style>
  .sales-card {
    width: auto;
    min-width: 250px;
    height: auto;
    background-color: #f8f8f8;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 20px;
    cursor: pointer;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    position: relative;
    /* For positioning the animation elements */
  }

  .sales-card:hover {
    transform: translateY(-5px);
    box-shadow: 0px 0px 10px 10px rgba(0, 0, 0, 0.2);
  }

  .sales-card .card-icon {
    font-size: 40px;
    color: #007bff;
  }

  .sales-card h6 {
    margin-top: 10px;
    font-size: 18px;
    font-weight: 600;
  }

  .sales-card span {
    font-size: 14px;
    color: #888;
  }

  /* Animation Elements */
  .animation-circle {
    position: absolute;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    background-color: #007bff;
    opacity: 0;
    z-index: -1;
  }

  .animation-circle.scale-up {
    animation: scaleUp 1s ease-in-out;
  }

  .animation-circle.fade-out {
    animation: fadeOut 1s ease-in-out;
  }

  @keyframes scaleUp {
    0% {
      transform: scale(0);
      opacity: 1;
    }

    100% {
      transform: scale(1.5);
      opacity: 0;
    }
  }

  @keyframes fadeOut {
    0% {
      opacity: 1;
    }

    100% {
      opacity: 0;
    }
  }

  .footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    text-align: center;
    padding: 20px;
    background-color: #f8f8f8;
    border-top: 1px solid #e1e1e1;
    /* Add additional styling for the footer if needed */
  }

  #search-bar {
    display: none;
  }

  #icone-menu {
    display: none;
  }

  /* Modal Styles */
.modal {
  display: none;
  position: fixed;
  z-index: 999;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.6);
}

.modal-content {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: #fff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  max-width: 80%;
  width: 500px;
}

.close-btn {
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 24px;
  background: none;
  border: none;
  cursor: pointer;
  color: #888;
}

.button-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  margin-top: 20px;
}

.option-btn {
  padding: 10px 20px;
  margin: 10px;
  background-color: #007bff;
  color: #fff;
  font-size: 18px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.option-btn:hover {
  background-color: #0056b3;
}
</style>
<body style="justify-content:center;margin:5em">
  <main style="justify-content:center;text-align:center">
    <div style="justify-content:center;text-align:center"><br>
      <h1 class="display-1 font-weight-bold"><b>UATM-GASA FORMATION</b></h1>
      <img src="./assets/images/logo_gasa.jpg" alt="logo" width="200" height="200" /><br /><br />
      <h2><b>Bienvenue dans votre espace personnel.</b></h2>
      <h3>Choisissez le centre sur lequel vous voulez travailler</h3><br>
    </div><!-- End Page Title -->
    <section class="section dashboard">
      <div class="row">
        <!-- Left side columns -->
        <div class="col-lg-16">
          <div class="row">
            <?php
                include("bdd.php");
                $centre=$_SESSION["centre"];
                $centres=explode("-",$centre);
                $taille=count($centres);
                for($i=0;$i<$taille;$i++){
                    $req=$db->prepare("SELECT * FROM centre WHERE nom_centre=?");
                    $req->execute(array($centres[$i]));
                    $donnes=$req->fetch();
                    echo '<div class="col-xxl-4 col-md-3">
                    <a href="#">
                      <div class="card info-card sales-card" onclick="animateSalesCard(this)">
        
                        <div class="card-body">
                          <h5 class="card-title">'.$donnes["nom_centre"].'</span></h5>
        
                          <div class="d-flex align-items-center">
                            <div class="ps-3">
                            <form action="centres.php?id_centre='.$donnes["id_centre"].'" method="post">
                            <select name="anneeScolaire">';
                            $req1=$db->query("SELECT * FROM annee_scolaire ORDER BY id_anneeScolaire DESC");
                            foreach($req1 as $cle=>$valeur){
                                echo "<option value=".$valeur["id_anneeScolaire"].">".$valeur["libelle_annee"]."</option>";
                            }
                            echo '</select>
                            <input type="submit" name="btn" class="btn btn-primary" value="choisir"/></form>
                            </div>
                          </div>
        
                        <!-- Animation Elements -->
                        <div class="animation-circle scale-up"></div>
                        <div class="animation-circle fade-out"></div>
                        </div>
                        </diV>
                      </a>
        
                    </div><!-- End Sales Card -->';
                }
            ?>
          </div>
        </div>
    </div>
    </section>
  </main><!-- End #main -->
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <!-- Vendor JS Files -->
  <script src="./assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="./assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="./assets/vendor/chart.js/chart.umd.js"></script>
  <script src="./assets/vendor/echarts/echarts.min.js"></script>
  <script src="./assets/vendor/quill/quill.min.js"></script>
  <script src="./assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="./assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="./assets/vendor/php-email-form/validate.js"></script>
  <!-- Template Main JS File -->
  <script src="./assets/js/main.js"></script>
</script>
</body>
</html>